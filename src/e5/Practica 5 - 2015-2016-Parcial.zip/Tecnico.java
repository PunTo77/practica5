package e5;

public class Tecnico{
	private String codigoLicencia;



}
