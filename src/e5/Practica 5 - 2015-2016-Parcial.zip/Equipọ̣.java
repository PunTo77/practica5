package e5;

import java.util.ArrayList;

public class Equipọ̣{
	private String nombre;
	private String ciudad;
	private String dreccionCampo;
	private ArrayList<Tecnico>Tecnicos;
	private ArrayList<Jugador>Jugadores;
	private ArrayList<Equipọ̣>Equipos;


}
