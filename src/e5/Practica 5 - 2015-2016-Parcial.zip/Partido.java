package e5;
public class Partido{
	private String fecha;
	private Equipo ganador;
	private Equipo [] enfrenta=new Equipo[2];
	private ArrayList<Estadistica> estadistica;



}
