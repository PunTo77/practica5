package e5;

public class Jugador{
	private int numDorsal;
	private String posicionCampo;


}
