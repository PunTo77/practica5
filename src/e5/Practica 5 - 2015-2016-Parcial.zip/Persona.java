package e5;

public class Persona {
	private String nombre;
	private String nif;


}
