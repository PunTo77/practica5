package e5;

public class Estadistica {
	private int minJugados;
	private int nGoles;
	private boolean tAmarilla;
	private boolean tRoja;



}
